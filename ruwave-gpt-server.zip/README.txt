Инструкция по запуску на Railway:

1. Перейдите на https://railway.app
2. Войдите через GitHub
3. Нажмите "New Project" > "Deploy from GitHub repo"
4. Залейте содержимое этой папки на GitHub
5. Railway сам всё установит
6. В разделе Variables добавьте:
   OPENAI_API_KEY = ваш API ключ от OpenAI
7. Нажмите "Deploy" — и получите ссылку на сервер

Готово!
